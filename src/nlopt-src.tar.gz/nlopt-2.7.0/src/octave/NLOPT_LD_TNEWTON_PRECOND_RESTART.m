% NLOPT_LD_TNEWTON_PRECOND_RESTART: Preconditioned truncated Newton with restarting (local, derivative-based)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_TNEWTON_PRECOND_RESTART
  val = 18;
