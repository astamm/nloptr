% NLOPT_LN_AUGLAG: Augmented Lagrangian method (local, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_LN_AUGLAG
  val = 30;
