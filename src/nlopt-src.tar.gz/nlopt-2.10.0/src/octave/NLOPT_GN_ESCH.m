% NLOPT_GN_ESCH: ESCH evolutionary strategy
%
% See nlopt_minimize for more information.
function val = NLOPT_GN_ESCH
  val = 42;
